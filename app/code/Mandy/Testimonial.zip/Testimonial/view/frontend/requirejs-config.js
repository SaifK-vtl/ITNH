var config = {
    map: {
        '*': {
            'mandy_testimonial': 'Mandy_Testimonial/js/testimonial',
        }
    }
};
